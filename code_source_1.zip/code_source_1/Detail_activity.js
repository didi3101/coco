import { useNavigation } from "@react-navigation/native";
import React, { useState, useRef } from "react";
import { View, Text, Button, useWindowDimensions, Platform, Dimensions, TextInput, Image, ScrollView, Pressable, TouchableOpacity, FlatList, Modal } from "react-native";
import { Octicons, FontAwesome5, FontAwesome, AntDesign, Feather } from '@expo/vector-icons';
import styleH from "./style_home";
import RBSheet from "react-native-raw-bottom-sheet";
import MapView, { Marker } from "react-native-maps";


export default function HomeScreen(props) {
  const navigation = useNavigation();
  const [modVisible, setModVisible] = useState(false);
  const refRBSheet = useRef();
  const activite = useRef();
  const zone = useRef();
  const bottom = useRef(true);
  const dispo = useRef();


  const { width, height } = useWindowDimensions();

  const PressCirc = () => {
    // setModalVisible(true)
    // setActiviteVisible(false)
    refRBSheet.current.open()
    activite.current.close()
    zone.current.close()
    dispo.current.close()
  };

  const PressAct = () => {
    // setActiviteVisible(true)
    // setModalVisible(false)
    activite.current.open()
    refRBSheet.current.close()
    zone.current.close()
    dispo.current.close()
  };

  const PressZone = () => {
    // setZoneVisible(true)
    // setActiviteVisible(false)
    // setModalVisible(false)
    zone.current.open()
    activite.current.close()
    refRBSheet.current.close()
    dispo.current.close()
  };

  const PressDisp = () => {
    dispo.current.open()
    zone.current.close()
    activite.current.close()
    refRBSheet.current.close()
  };


  return (
    <View style={styleH.container}>

      <TouchableOpacity style={styleH.alert}>
        <Octicons
          name="bell-fill"
          size={25}
          color="#735459"
        />
      </TouchableOpacity>

      <View style={styleH.search}>
        <View style={styleH.soussearch}>
          <AntDesign
            name="search1"
            size={30}
            color="#735459"
          />
          <TextInput
            placeholder="Search Destination"
            style={styleH.txtsearch}
          />
        </View>

        <TouchableOpacity style={styleH.slide}>
          <FontAwesome5
            name="sliders-h"
            size={30}
            color="#fff"
          />
        </TouchableOpacity>
      </View>

      <View style={styleH.scroll}>
        <ScrollView horizontal={true}>
          <TouchableOpacity style={styleH.men1}>
            <Text style={styleH.mentxte}>Tout</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styleH.men}>
            <Text style={styleH.mentxt}>Activités</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styleH.men}>
            <Text style={styleH.mentxt}>Restaurants</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styleH.men}>
            <Text style={styleH.mentxt}>Logement</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
      <View style={styleH.rec}>
        <Text style={styleH.recomm}>Recommandé</Text>
        <TouchableOpacity>
          <Text style={styleH.recomm2}>Voir tout</Text>
        </TouchableOpacity>
      </View>

      <ScrollView>
        <View style={styleH.cont}>
          <View style={styleH.sousCont}>
            <Image
              source={require('../../../assets/images/11.png')}
              style={styleH.img}
            />
            <Text style={styleH.souttitre}>Explorer la ville</Text>
            <Text style={styleH.souttitre2}>
              <Feather
                name="trending-up"
                size={10}
                color="#84ABE4"
              />
              Bonne opportunitée
            </Text>
            <View style={styleH.contabs}>
              <View style={styleH.contabsNb1}>
                <Text style={styleH.contabstxt}>300m</Text>
              </View>
              <View style={styleH.contabsNb}>
                <FontAwesome
                  name="bookmark"
                  size={13}
                  color="#FFFFFF"
                />
              </View>
            </View>
            <View style={styleH.contprix}>
              <View style={styleH.contNb}>
                <Text style={styleH.conttxt}>400£</Text>
              </View>
            </View>
          </View>

          <View style={styleH.sousCont}>
            <Image
              source={require('../../../assets/images/22.png')}
              style={styleH.img}
            />
            <Text style={styleH.souttitre}>Randonnée en forêt</Text>
            <Text style={styleH.souttitre2}>
              <Feather
                name="trending-up"
                size={10}
                color="#84ABE4"
              />
              Bonne opportunitée
            </Text>
            <View style={styleH.contabs}>
              <View style={styleH.contabsNb1}>
                <Text style={styleH.contabstxt}>300m</Text>
              </View>
              <View style={styleH.contabsNb}>
                <FontAwesome
                  name="bookmark"
                  size={13}
                  color="#FFFFFF"
                />
              </View>
            </View>
            <View style={styleH.contprix}>
              <View style={styleH.contNb}>
                <Text style={styleH.conttxt}>400£</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styleH.contC}>
          <View style={styleH.contCircuit}>
            <Text style={styleH.circuittxt}>
              Offrez-vous un circuit personnalisé en renseignant
              vos envies
            </Text>
            <TouchableOpacity
              style={styleH.circuitbtn2}
              // onPress={() => setModalVisible(true)}
              onPress={() => refRBSheet.current.open()}
            >
              <Text style={styleH.circuittxt2}>
                Circuit
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styleH.cont}>
          <View style={styleH.sousCont}>
            <Image
              source={require('../../../assets/images/33.png')}
              style={styleH.img}
            />
            <Text style={styleH.souttitre}>Sport nautique</Text>
            <Text style={styleH.souttitre2}>
              <Feather
                name="trending-up"
                size={10}
                color="#84ABE4"
              />
              Bonne opportunitée
            </Text>
            <View style={styleH.contabs}>
              <View style={styleH.contabsNb1}>
                <Text style={styleH.contabstxt}>300m</Text>
              </View>
              <View style={styleH.contabsNb}>
                <FontAwesome
                  name="bookmark"
                  size={13}
                  color="#FFFFFF"
                />
              </View>
            </View>
            <View style={styleH.contprix}>
              <View style={styleH.contNb}>
                <Text style={styleH.conttxt}>400£</Text>
              </View>
            </View>
          </View>

          <View style={styleH.sousCont}>
            <Image
              source={require('../../../assets/images/44.png')}
              style={styleH.img}
            />
            <Text style={styleH.souttitre}>Randonnée en forêt</Text>
            <Text style={styleH.souttitre2}>
              <Feather
                name="trending-up"
                size={10}
                color="#84ABE4"
              />
              Bonne opportunitée
            </Text>
            <View style={styleH.contabs}>
              <View style={styleH.contabsNb1}>
                <Text style={styleH.contabstxt}>300m</Text>
              </View>
              <View style={styleH.contabsNb}>
                <FontAwesome
                  name="bookmark"
                  size={13}
                  color="#FFFFFF"
                />
              </View>
            </View>
            <View style={styleH.contprix}>
              <View style={styleH.contNb}>
                <Text style={styleH.conttxt}>400£</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styleH.cont}>
          <View style={styleH.sousCont}>
            <Image
              source={require('../../../assets/images/55.png')}
              style={styleH.img}
            />
            <Text style={styleH.souttitre}>Explorer la ville</Text>
            <Text style={styleH.souttitre2}>
              <Feather
                name="trending-up"
                size={10}
                color="#84ABE4"
              />
              Bonne opportunitée
            </Text>
            <View style={styleH.contabs}>
              <View style={styleH.contabsNb1}>
                <Text style={styleH.contabstxt}>300m</Text>
              </View>
              <View style={styleH.contabsNb}>
                <FontAwesome
                  name="bookmark"
                  size={13}
                  color="#FFFFFF"
                />
              </View>
            </View>
            <View style={styleH.contprix}>
              <View style={styleH.contNb}>
                <Text style={styleH.conttxt}>400£</Text>
              </View>
            </View>
          </View>

          <View style={styleH.sousCont}>
            <Image
              source={require('../../../assets/images/66.png')}
              style={styleH.img}
            />
            <Text style={styleH.souttitre}>Randonnée en forêt</Text>
            <Text style={styleH.souttitre2}>
              <Feather
                name="trending-up"
                size={10}
                color="#84ABE4"
              />
              Bonne opportunitée
            </Text>
            <View style={styleH.contabs}>
              <View style={styleH.contabsNb1}>
                <Text style={styleH.contabstxt}>300m</Text>
              </View>
              <View style={styleH.contabsNb}>
                <FontAwesome
                  name="bookmark"
                  size={13}
                  color="#FFFFFF"
                />
              </View>
            </View>
            <View style={styleH.contprix}>
              <View style={styleH.contNb}>
                <Text style={styleH.conttxt}>400£</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>

      <RBSheet
        ref={refRBSheet}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent"
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,

            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            width: "100%",
            //     borderColor: "black",
            // borderStyle: "solid",
            // borderWidth: 2,
          },
        }}
      >
        <View style={{ flex: 1 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>
                  Circuit
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>
                  Activité
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>
                  Zone
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>
                  Disponibilité
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* {circuitVisible && */}
          <ScrollView style={{ zIndex: 1 }}>
            <View style={styleH.contCircuit000}>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate('Circuit')
                  refRBSheet.current.close()
                }}
              >
                <Image
                  source={require('../../../assets/images/01.png')}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt10100}>
                    Circuit en famille
                  </Text>
                </TouchableOpacity>
              </TouchableOpacity>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate('Circuit')
                  refRBSheet.current.close()
                }}
              >
                <Image
                  source={require('../../../assets/images/02.png')}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt0100}>
                    Circuit en amis
                  </Text>
                </TouchableOpacity>
              </TouchableOpacity>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate('Circuit')
                  refRBSheet.current.close()
                }}
              >
                <Image
                  source={require('../../../assets/images/03.png')}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt0100}>
                    Circuit en couple
                  </Text>
                </TouchableOpacity>
              </TouchableOpacity>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate('Circuit')
                  refRBSheet.current.close()
                }}
              >
                <Image
                  source={require('../../../assets/images/04.png')}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt0100}>
                    Circuit en solo
                  </Text>
                </TouchableOpacity>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </RBSheet>


      <RBSheet
        ref={activite}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent"
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
          },
        }}
      >
        <View style={{ flex: 2 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>
                  Circuit
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>
                  Activité
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>
                  Zone
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>
                  Disponibilité
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <ScrollView style={{ zIndex: 1 }}>
          <View style={styleH.containerFlex}>
            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/11.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/66.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/33.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/44.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/77.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/99.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/6.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require('../../../assets/images/88.png')}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather
                  name="trending-up"
                  size={10}
                  color="#84ABE4"
                />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome
                    name="bookmark"
                    size={13}
                    color="#FFFFFF"
                  />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </RBSheet>

      <RBSheet
        ref={zone}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent"
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
          },
        }}
      >
        <View style={{ flex: 2 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>
                  Circuit
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>
                  Activité
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>
                  Zone
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>
                  Disponibilité
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <ScrollView style={{ zIndex: 1 }}>
          <View>
            <MapView
              // ref={mapRef}
              style={{ width, height }}
              showsUserLocation
              followsUserLocation
            >

            </MapView>
          </View>
        </ScrollView>
      </RBSheet>

      <RBSheet
        ref={dispo}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent"
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
          },
        }}
      >
        <View style={{ flex: 1 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>
                  Circuit
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>
                  Activité
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>
                  Zone
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>
                  Disponibilité
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <ScrollView style={{ zIndex: 1 }}>
          <View style={styleH.contDispo}>
            <TouchableOpacity style={styleH.sousDispo} onPress={() => setModVisible(true)}>
              <Text style={styleH.sousDispoTxt}>Je suis disponible</Text>
              <AntDesign
                name="right"
                size={15}
                color="#84ABE4"
              />
            </TouchableOpacity>
            <TouchableOpacity style={styleH.sousDispo}>
              <Text style={styleH.sousDispoTxt}>Je suis disponible pendent</Text>
              <AntDesign
                name="right"
                size={15}
                color="#84ABE4"
              />
            </TouchableOpacity>
            <TouchableOpacity style={styleH.sousDispo}>
              <Text style={styleH.sousDispoTxt}>Je me déplace</Text>
              <AntDesign
                name="right"
                size={15}
                color="#84ABE4"
              />
            </TouchableOpacity>
            <TouchableOpacity style={styleH.sousDispo}>
              <Text style={styleH.sousDispoTxt}>Prendre en compte la météo</Text>
              <AntDesign
                name="right"
                size={15}
                color="#84ABE4"
              />
            </TouchableOpacity>
          </View>
        </ScrollView>

      </RBSheet>



    </View>
  );
}