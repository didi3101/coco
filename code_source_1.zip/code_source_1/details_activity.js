import React, { useState, useEffect, useContext, useLayoutEffect } from "react";
import { View, Text, Image, FlatList, Pressable, useWindowDimensions, TouchableOpacity, Modal, ScrollView } from "react-native";

import style from "./style";
import { useNavigation } from "@react-navigation/native";
import MapView, { Marker } from "react-native-maps";
import AsyncImage from "../../components/AsyncImage";
import { FirebaseContext } from "../../../helpers/Firebase";
import styleH from "./style_home";
import { functions } from '../../../helpers/Constants'
var moment = require('moment');

import {
  Octicons,
  FontAwesome5,
  FontAwesome,
  AntDesign,
  Feather,
  Foundation,
  MaterialCommunityIcons,
} from "@expo/vector-icons";

import {
  BallIndicator,
  BarIndicator,
  DotIndicator,
  MaterialIndicator,
  PacmanIndicator,
  PulseIndicator,
  SkypeIndicator,
  UIActivityIndicator,
  WaveIndicator,
} from "react-native-indicators";

const DescActivite = ({ route }) => {
  const navigation = useNavigation();
  const [detail_data, setDetail_data] = useState(route.params.act);
  const [loadingOther, setLoadinOther] = useState(false);
  const [listeActivite, setListeActivite] = useState([]);
  const [startFilter, setStartFilter] = useState(false);
  const [loadingActivity, setLoadingActivity] = useState(false);
  const [Activity, setActivity] = useState([]);
  const [ActivityFilter, setActivityFilter] = useState([]);

  const [services, setServices] = useState([]);
  const [servicesFilter, setServicesFilter] = useState([]);
  const [presente, setPresente] = useState(true);
  const [detail, setDetail] = useState(false);
  const [formalite, setFormalite] = useState(false);
  const [tarif, setTarif] = useState([]);
  const [photos, setPhotos] = useState([]);

  const [loadingPhotos, setLoadingPhotos] = useState(false);
  const dataBase = useContext(FirebaseContext);

  const horraires = [
    {
      plageH: '07H:09H'
    },
    {
      plageH: '10H:12H'
    },
    {
      plageH: '13H:15H'
    },
    {
      plageH: '16H:18H'
    }
  ]

  const getURLPhotos = async () => {
    setLoadingPhotos(true)
    let tab_photos = []
    let nbr_ph = 0
    route.params.act.photos.forEach(async ph => {

      let link = await dataBase.getUrl(functions.imageUrl(ph))
        .then((lk) => {
          tab_photos.push(lk)
          nbr_ph++
        })

      if (nbr_ph === route.params.act.photos.length) {
        setPhotos(tab_photos)
        setLoadingPhotos(false)
      }
    });
  }

  useLayoutEffect(() => {
    setPhotos(route.params.act.photos)
    setTarif(route.params.act.tarif)
  }, []);


  return (
    <View style={style.container}>
      <ScrollView style={{ flex: 1 }}>
        <View style={style.contH}>
          <View style={style.head}>
            <FlatList
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              data={photos}
              renderItem={({ item, index }) => (
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start' }}>
                  <AsyncImage
                    key={index}
                    source={{ uri: item }}
                    style={{ width: 250, height: 250, margin: 10 }}
                  // style={style.img}
                  />
                </View>

              )}
            />
            <Text style={style.plagetxt}>{route.params.act.nom}</Text>
            <View style={style.contStar}>

            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
              <Text style={{ fontFamily: 'cambeyRegular', fontSize: 15, fontWeight: '700' }}>
                Note : {route.params.act.notemoyenne}/5
              </Text>
              <TouchableOpacity style={{ width: 120, height: 30, justifyContent: 'center', alignItems: 'center', backgroundColor: 'yellow', borderRadius: 10 }}>
                <Text>Commentaires</Text>
              </TouchableOpacity>
            </View>

            <View style={{ flexDirection: 'column', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
              <Text style={{ fontFamily: 'cambeyRegular', fontSize: 15, fontWeight: '700' }}>
                Tarifs
              </Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <ScrollView horizontal={true} style={{ width: '100%', borderRadius: 10, backgroundColor: '#dbdbdb', padding: 10 }} >

                  {
                    tarif !== undefined && tarif !== null ?
                      Object.keys(tarif).map((tf, id_tf) =>
                        <View style={{ flexDirection: 'column', justifyContent: 'space-around', alignItems: 'center', paddingLeft: 10, height: 72, }} key={id_tf}>
                          <Text style={{ fontFamily: 'abelRegular', fontSize: 15, textDecorationLine: 'underline' }} >
                            {tarif[tf] != null ? tarif[tf].nom : tf}
                          </Text>
                          <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                            {tarif[tf] != null ? tarif[tf].prix + ' €' : '-'}
                          </Text>
                          {/* <Text style={{ fontFamily: 'cambeyRegular', fontSize: 15, fontWeight: '700' }} key={id_tf}>
                          {tf.duree !== undefined && tf.duree !== null &&  moment(tf.duree.toDate()).format("HH") }
                        </Text> */}
                        </View>
                      )
                      :
                      <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                        Gratuit
                      </Text>
                  }
                </ScrollView>

              </View>

              <Text style={{ fontFamily: 'cambeyRegular', fontSize: 15, fontWeight: '700' }}>
                Horraires
              </Text>

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <ScrollView horizontal={true} style={{ width: '100%', borderRadius: 10, backgroundColor: '#dbdbdb', padding: 10 }} >

                  {
                    horraires !== undefined && horraires !== null ?
                      Object.keys(horraires).map((hor, id_hor) =>
                        <View style={{ flexDirection: 'column', justifyContent: 'space-around', alignItems: 'center', paddingLeft: 10, height: 72, }} key={id_hor}>

                          <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                            {horraires[hor] != null && horraires[hor].plageH}
                          </Text>

                        </View>
                      )
                      :
                      <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                        Aucune Plage Horraire prévue.
                      </Text>
                  }
                </ScrollView>

              </View>
              {
                route.params.act.tempsActivitee !== null && route.params.act.tempsActivitee !== undefined &&
                <View style={{ width: '100%', marginTop: 10, height: 50, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                    Durée d'activité : {route.params.act.tempsActivitee + ' Minutes'}
                  </Text>
                </View>

              }

              {
                route.params.act.nombreParticipantsMin !== undefined && route.params.act.nombreParticipantsMin !== null && route.params.act.nombreParticipantsMax !== undefined && route.params.act.nombreParticipantsMax !== null &&
                <View style={{ width: '100%', marginTop: 10, height: 50, flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <Text style={{ fontFamily: 'cambeyRegular', color: '#000', fontSize: 15, fontWeight: '700' }}>
                    Nombre de Participants Min : {route.params.act.nombreParticipantsMin}
                  </Text>
                  <Text style={{ fontFamily: 'cambeyRegular', color: '#000', fontSize: 15, fontWeight: '700' }}>
                    Nombre de Participants Max : {route.params.act.nombreParticipantsMin}
                  </Text>
                </View>

              }

              {
                route.params.act.ageMin !== null && route.params.act.ageMax !== null && route.params.act.ageMin !== undefined && route.params.act.ageMax !== undefined &&
                <View style={{ width: '100%', marginTop: 10, height: 50, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                    Age Min : {route.params.act.ageMin} ans
                  </Text>
                  <Text style={{ fontFamily: 'cambeyRegular', color: '#735459', fontSize: 15, fontWeight: '700' }}>
                    Age Max : {route.params.act.ageMax} ans
                  </Text>
                </View>

              }
            </View>
          </View>

          <View style={{ width: '100%' }}>
            <View style={{ width: '100%', height: 40, flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
              <TouchableOpacity style={{ width: '40%', justifyContent: 'center', alignItems: 'center', borderRightWidth: 1, borderRightColor: 'grey' }} onPress={() => { setPresente(true), setDetail(false), setFormalite(false) }}><Text style={{ fontFamily: 'abelRegular', fontSize: 20, color: 'black' }}>Présentation</Text></TouchableOpacity>
              <TouchableOpacity style={{ width: '30%', justifyContent: 'center', alignItems: 'center' }} onPress={() => { setPresente(false), setDetail(false), setFormalite(true) }}><Text style={{ fontFamily: 'abelRegular', fontSize: 20, color: 'black' }} >Formalité</Text></TouchableOpacity>
            </View>

            {
              detail &&
              <View style={{ width: '100%', flexDirection: 'column', alignItems: 'center' }}>
                <FlatList
                  horizontal={true}
                  showsHorizontalScrollIndicator={false}
                  data={photos}
                  renderItem={({ item, index }) => (
                    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start' }}>
                      <AsyncImage
                        key={index}
                        source={{ uri: item }}
                        style={{ width: 250, height: 250, margin: 10 }}
                      // style={style.img}
                      />
                    </View>

                  )}
                />
              </View>
            }




            {
              presente &&
              <View style={{ width: '100%', marginTop: 15, padding: 20 }}>
                {/* <Text style={style.contDesc}>Description</Text> */}
                <Text style={{ fontFamily: 'abelRegular', fontSize: 15 }}>
                  {route.params.act.description}
                </Text>
              </View>
            }
          </View>

          {
            formalite &&
            <View style={{ width: '100%', marginTop: 15 }}>
              {/* <Text style={style.contDesc}>Description</Text> */}
              <Text style={{ fontFamily: 'abelRegular', fontSize: 15 }}>
                Formalités de Participation
              </Text>
            </View>
          }
        </View>

      </ScrollView>
    </View>
  );
};

export default DescActivite;
