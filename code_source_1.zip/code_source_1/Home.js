import { useNavigation } from "@react-navigation/native";
import React, {
  useState,
  useRef,
  useEffect,
  useLayoutEffect,
  useContext,
} from "react";
import {
  View,
  Text,
  Button,
  useWindowDimensions,
  Platform,
  Dimensions,
  TextInput,
  Image,
  ScrollView,
  Pressable,
  TouchableOpacity,
  FlatList,
  Modal,
  ImageBackground,
} from "react-native";
import {
  Octicons,
  FontAwesome5,
  FontAwesome,
  AntDesign,
  Feather,
  Foundation,
  MaterialCommunityIcons,
} from "@expo/vector-icons";
import styleH from "./style_home";
import RBSheet from "react-native-raw-bottom-sheet";
import MapView, { Marker } from "react-native-maps";
import { FirebaseContext } from "../../../helpers/Firebase";
import { functions } from '../../../helpers/Constants'
// import { imageDefault } from "../../../helpers/Constants/constants";
import AsyncImage from "../../components/AsyncImage";
import {
  BallIndicator,
  BarIndicator,
  DotIndicator,
  MaterialIndicator,
  PacmanIndicator,
  PulseIndicator,
  SkypeIndicator,
  UIActivityIndicator,
  WaveIndicator,
} from "react-native-indicators";

export default function HomeScreen(props) {
  const navigation = useNavigation();
  const [modVisible, setModVisible] = useState(false);
  const refRBSheet = useRef();
  const activite = useRef();
  const zone = useRef();
  const bottom = useRef(true);
  const dispo = useRef();
  const dataBase = useContext(FirebaseContext);
  const [loadingActivity, setLoadingActivity] = useState(false);
  const [filterData, setFilterData] = useState(false);
  const [textFilter, setTextFilter] = useState("");

  const default_image_activity = require("../../../assets/images/55.png");
  const img_def =
    "https://pixnio.com/free-images/2017/10/06/2017-10-06-16-00-58.jpg";
  const [categoryActivity, setcategoryActivity] = useState([]);
  const [Activity, setActivity] = useState([]);
  const [ActivityFilter, setActivityFilter] = useState([]);
  const [startFilter, setStartFilter] = useState(false);

  const [services, setServices] = useState([]);
  const [servicesFilter, setServicesFilter] = useState([]);

  const getActivityCategory = async () => {


    let data_s = []

    let data_i = []

    var res_int = (await dataBase.getAllDocument("type/public/categories").get()).docs
      .map(async cp => {
        var data_int = cp.data()
        data_int.link = cp.ref.path
        data_i.push(data_int)

      })

    var res_serv = (await dataBase.getAllDocument("type/professionnel/categories").get()).docs
      .map(async cpro => {
        var data_serv = cpro.data()
        data_serv.link = cpro.ref.path
        data_s.push(data_serv)
      })

    let combined = [...data_s, ...data_i]
    setcategoryActivity(combined);

    // let data_colibrika = await dataBase
    //   .getAllDocument("type/professionnel/categories")
    //   .get()
    //   .then(async (cat) => {
    //     let catb = cat.docs.map((doc) => doc.data());
    //     let catbx = cat.docs.map((doc) => console.log(doc.ref.Wa));
    //     // catb.forEach(element => {
    //     //     console.log(element)
    //     // });
    //     setcategoryActivity(catb);
    //   });
  };

  const getListeServices = async () => {
    setLoadingActivity(true);
    await dataBase
      .getGroupDocument("services")
      .get()
      .then((serv) => {
        let data_serv = serv.docs.map((docss) => docss.data());
        let nbr_services = 1;
        let data_all_services = [];

        data_serv.forEach(async (elt) => {
          if (elt.imageProfile !== "null") {
            nbr_services++;
            data_all_services.push({
              ...elt,
              urlImg: elt.imageProfile,
              type: "pro",
            });
            if (nbr_services === data_serv.length) {
              await dataBase
                .getAllDocument("type/public/centre-interets")
                .get()
                .then((ci) => {
                  let data_ci = ci.docs.map((doc_ci) => doc_ci.data());
                  let nbr_ci = 1;
                  let data_tab_ci = [];
                  data_ci.forEach(async (elt_ci) => {
                    // console.log(elt_ci.categorie.)
                    nbr_ci++;
                    data_tab_ci.push({
                      ...elt_ci,
                      urlImg_ci: elt_ci.imageProfile,
                      type: "public",
                    });
                    // console.log(urlimg_ci)
                    if (nbr_ci === data_ci.length) {
                      let combined = [
                        ...data_all_services,
                        ...data_tab_ci,
                      ];
                      let tab_activity = [];
                      tab_activity.push(...combined);
                      tab_activity.sort(() => Math.random() - 0.5);

                      setServices(tab_activity);
                      setLoadingActivity(false);
                    }
                  });
                });
            }
          } else {
            nbr_services++;
            if (nbr_services === data_serv.length) {
              await dataBase
                .getAllDocument("type/public/centre-interets")
                .get()
                .then((ci) => {
                  let data_ci = ci.docs.map((doc_ci) => doc_ci.data());
                  let nbr_ci = 1;
                  let data_tab_ci = [];
                  data_ci.forEach(async (elt_ci) => {
                    nbr_ci++;
                    data_tab_ci.push({
                      ...elt_ci,
                      urlImg_ci: elt_ci.imageProfile,
                      type: "public",
                    });
                    if (nbr_ci === data_ci.length) {
                      let combined = [...data_all_services, ...data_tab_ci];
                      tab_activity = [];
                      tab_activity.push(...combined);
                      tab_activity.sort(() => Math.random() - 0.5);
                      setServices(tab_activity);
                      setLoadingActivity(false);
                    }
                  });
                });
            }
          }
        });
      });
  };

  const getAllActivity = async () => {
    setStartFilter(false);
    setLoadingActivity(true);
    let colibrika_activity_images = await dataBase
      .getOneDocument("supabaseBackup", "ActivityImage")
      .get();
    colibrika_activity_images = colibrika_activity_images.data().data;

    let colibrika_activity = await dataBase
      .getOneDocument("supabaseBackup", "Activity")
      .get();
    colibrika_activity = colibrika_activity.data().data;
    if (colibrika_activity.length > 0) {
      let data_activity = [],
        nbr_tour = 0;
      colibrika_activity.forEach(async (doc_act) => {
        nbr_tour++;
        const data_image = colibrika_activity_images.find(
          (aimg) => aimg.activity_fk === doc_act.id
        );
        if (data_image === undefined) {
          data_activity.push({
            ...doc_act,
            activite_image: default_image_activity,
            local_url: true,
          });
        } else {
          data_activity.push({
            ...doc_act,
            activite_image: data_image.storage_url,
            local_url: false,
          });
        }
        if (nbr_tour === colibrika_activity.length) {
          setActivity(data_activity);
          setLoadingActivity(false);
        }
      });
    }
  };

  const tout_charger = (fk_act) => {
    getAllActivity();
  };

  const getFilterData = () => {
    if (filterData) {
      setFilterData(false);
    } else {
      setFilterData(true);
    }
  };

  const filter_data = (fk_act) => {
    setStartFilter(true);
    setLoadingActivity(true);
    let filter_act = services.filter(ls => ls.categorie._delegate._key.path.segments[ls.categorie._delegate._key.path.segments.length - 1] === fk_act.split('/')[3])
    setServicesFilter(filter_act)
    setLoadingActivity(false);
  };

  const search_data = (nom) => {
    if (nom !== "") {
      setStartFilter(true);
      setLoadingActivity(true);
      setServicesFilter(
        services.filter((item) =>
          item.nom.toLowerCase().includes(nom.toLowerCase())
        )
      );
      setLoadingActivity(false);
    } else {
      setStartFilter(false);
    }
  };

  const [listeService, setListeService] = useState([])
  const [listeInteret, setListeInteret] = useState([])

  const chargerServices = async () => {
    setLoadingActivity(true);
    const t = await fetch(
      "https://us-central1-colibrika-83862.cloudfunctions.net/getServices/"
    )
      .then((t) => t.json())
    let datax = []
    let cpt = 1
    await Promise.all(t.map(async x => {

      cpt++
      datax.push({
        ...x,
        link: x.imageProfile,
        type: 'pro'
      })
      if (t.length === cpt) {
        setListeService(datax)
        return datax
        setLoadingActivity(false);
      }
    }))
  }


  const chargerInteret = async () => {
    setLoadingActivity(true);
    const u = await fetch(
      "https://us-central1-colibrika-83862.cloudfunctions.net/getCentreInterets/"
    )
      .then((u) => u.json())
    let udata = []
    let ucpt = 1
    await Promise.all(u.map(async y => {
      ucpt++
      udata.push({
        ...y,
        link: y.imageProfile,
        type: 'public'
      })
      if (u.length === ucpt) {
        setListeInteret(udata)
        return udata
        setLoadingActivity(false);
      }
    }))
  }

  useLayoutEffect(() => {
    chargerServices()
    chargerInteret()
    getListeServices();
    getActivityCategory();
  }, []);

  const { width, height } = useWindowDimensions();

  const PressCirc = () => {
    refRBSheet.current.open();
    activite.current.close();
    zone.current.close();
    dispo.current.close();
  };

  const PressAct = () => {
    activite.current.open();
    refRBSheet.current.close();
    zone.current.close();
    dispo.current.close();
  };

  const PressZone = () => {
    // setZoneVisible(true)
    // setActiviteVisible(false)
    // setModalVisible(false)
    zone.current.open();
    activite.current.close();
    refRBSheet.current.close();
    dispo.current.close();
  };

  const PressDisp = () => {
    dispo.current.open();
    zone.current.close();
    activite.current.close();
    refRBSheet.current.close();
  };

  return (
    <View style={styleH.container}>
      <TouchableOpacity style={styleH.alert}>
        <Octicons name="bell-fill" size={25} color="#735459" />
      </TouchableOpacity>

      <View style={styleH.search}>
        <View style={styleH.soussearch}>
          <AntDesign name="search1" size={30} color="#735459" />
          <TextInput
            placeholder="Rechercher activité"
            style={styleH.txtsearch}
            onChangeText={(textFilter) => search_data(textFilter)}
          />
        </View>

        <TouchableOpacity style={styleH.slide} onPress={() => getFilterData()}>
          <FontAwesome5 name="sliders-h" size={30} color="#fff" />
        </TouchableOpacity>
      </View>

      {filterData && (
        <View style={styleH.scroll}>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            {/* <TouchableOpacity style={styleH.men1} onPress={() => tout_charger()} >
            <Text style={styleH.mentxte}>Tout</Text>
          </TouchableOpacity> */}

            {categoryActivity.map((cat, id_cat) => (
              <TouchableOpacity
                style={styleH.men}
                key={id_cat}
                onPress={() => filter_data(cat.link)}
              >
                <Text style={styleH.mentxt}>{cat.nom}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      <View style={styleH.rec}>
        <Text style={styleH.recomm}>Recommandé</Text>
        <TouchableOpacity onPress={() => getAllActivity()}>
          <Text style={styleH.recomm2}>Voir tout</Text>
        </TouchableOpacity>
      </View>

      <ScrollView>
        <View style={styleH.cont}>
          {loadingActivity ? (
            <View style={styleH.content_loading}>
              <MaterialIndicator color="#735459" />
            </View>
          ) : startFilter ? (
            servicesFilter.map((act, id_act) =>
              act.type === "pro" ? (
                <TouchableOpacity
                  style={styleH.sousCont}
                  key={id_act}
                  onPress={() =>
                    navigation.navigate("detail_activite", { act: act, services: services })
                  }
                >

                  <AsyncImage

                    source={
                      act.imageProfile !== undefined && { uri: act.urlImg }
                    }
                    style={{
                      width: "100%",
                      height: 135,
                      borderRadius: 8,
                    }}
                  />
                  <View style={styleH.content_title}>
                    <Text style={styleH.souttitre}>
                      {act.nom.substring(0, 30)}...
                    </Text>
                  </View>


                  <View style={styleH.contabs}>
                    {
                      act.tempsActivitee !== null && act.tempsActivitee !== undefined ?
                        <View style={styleH.contabsNb1}>
                          <Text style={styleH.tempActivite}>
                            {act.tempsActivitee + ' Min'}
                          </Text>
                        </View>
                        :
                        <View style={styleH.contabsNb1_sc}>

                        </View>
                    }

                    {
                      act.nombreParticipantsMin !== undefined && act.nombreParticipantsMin !== null && act.nombreParticipantsMax !== undefined && act.nombreParticipantsMax !== null &&
                      <View style={styleH.contabsNb}>
                        <Text
                          style={{
                            color: "white",
                            fontFamily: "abelRegular",
                            fontSize: 8,
                          }}
                        >
                          {act.nombreParticipantsMin} -{" "}
                          {act.nombreParticipantsMax}
                        </Text>
                        <Foundation
                          name="male-female"
                          size={13}
                          color="#FFFFFF"
                        />
                      </View>
                    }


                  </View>

                  <View style={styleH.contprix}>
                    {
                      act.ageMin !== null && act.ageMax !== null && act.ageMin !== undefined && act.ageMax !== undefined &&
                      <View style={styleH.contNb}>
                        <Text style={styleH.conttxt}>
                          {act.ageMin} - {act.ageMax} ans
                        </Text>
                      </View>
                    }

                  </View>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  style={styleH.sousCont}
                  key={id_act}
                  onPress={() =>
                    navigation.navigate("detail_activite", { act: act, services: services })
                  }
                >

                  <AsyncImage
                    source={
                      act.imageProfile !== undefined && { uri: act.urlImg_ci }
                    }
                    style={{
                      width: "100%",
                      height: 135,
                      borderRadius: 8,
                    }}
                  />
                  <View style={styleH.content_title}>
                    <Text style={styleH.souttitre}>
                      {act.nom.substring(0, 30)}...
                    </Text>
                  </View>

                  <View style={styleH.contabs}>
                    {
                      act.tempsActivitee !== null && act.tempsActivitee !== undefined ?
                        <View style={styleH.contabsNb1}>
                          <Text style={styleH.tempActivite}>
                            {act.tempsActivitee + ' Min'}
                          </Text>
                        </View>
                        :
                        <View style={styleH.contabsNb1_sc}>

                        </View>
                    }


                  </View>

                  <View style={styleH.contprix}>

                  </View>
                </TouchableOpacity>
              )
            ))
            : (
              services.map((act, id_act) =>
                act.type === "pro" ? (
                  <TouchableOpacity
                    style={styleH.sousCont}
                    key={id_act}
                    onPress={() =>
                      navigation.navigate("detail_activite", { act: act, services: services })
                    }
                  >

                    <AsyncImage

                      source={
                        act.imageProfile !== undefined && { uri: act.urlImg }
                      }
                      style={{
                        width: "100%",
                        height: 135,
                        borderRadius: 8,
                      }}
                    />
                    <View style={styleH.content_title}>
                      <Text style={styleH.souttitre}>
                        {act.nom.substring(0, 30)}...
                      </Text>
                    </View>


                    <View style={styleH.contabs}>
                      {
                        act.tempsActivitee !== null && act.tempsActivitee !== undefined ?
                          <View style={styleH.contabsNb1}>
                            <Text style={styleH.tempActivite}>
                              {act.tempsActivitee + ' Min'}
                            </Text>
                          </View>
                          :
                          <View style={styleH.contabsNb1_sc}>

                          </View>
                      }

                      {
                        act.nombreParticipantsMin !== undefined && act.nombreParticipantsMin !== null && act.nombreParticipantsMax !== undefined && act.nombreParticipantsMax !== null &&
                        <View style={styleH.contabsNb}>
                          <Text
                            style={{
                              color: "white",
                              fontFamily: "abelRegular",
                              fontSize: 8,
                            }}
                          >
                            {act.nombreParticipantsMin} -{" "}
                            {act.nombreParticipantsMax}
                          </Text>
                          <Foundation
                            name="male-female"
                            size={13}
                            color="#FFFFFF"
                          />
                        </View>
                      }


                    </View>

                    <View style={styleH.contprix}>
                      {
                        act.ageMin !== null && act.ageMax !== null && act.ageMin !== undefined && act.ageMax !== undefined &&
                        <View style={styleH.contNb}>
                          <Text style={styleH.conttxt}>
                            {act.ageMin} - {act.ageMax} ans
                          </Text>
                        </View>
                      }

                    </View>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    style={styleH.sousCont}
                    key={id_act}
                    onPress={() =>
                      navigation.navigate("detail_activite", { act: act, services: services })
                    }
                  >

                    <AsyncImage
                      source={
                        act.imageProfile !== undefined && { uri: act.urlImg_ci }
                      }
                      style={{
                        width: "100%",
                        height: 135,
                        borderRadius: 8,
                      }}
                    />
                    <View style={styleH.content_title}>
                      <Text style={styleH.souttitre}>
                        {act.nom.substring(0, 30)}...
                      </Text>
                    </View>

                    <View style={styleH.contabs}>
                      {
                        act.tempsActivitee !== null && act.tempsActivitee !== undefined ?
                          <View style={styleH.contabsNb1}>
                            <Text style={styleH.tempActivite}>
                              {act.tempsActivitee + ' Min'}
                            </Text>
                          </View>
                          :
                          <View style={styleH.contabsNb1_sc}>

                          </View>
                      }


                    </View>

                    <View style={styleH.contprix}>

                    </View>
                  </TouchableOpacity>
                )
              ))
          }
        </View>
      </ScrollView>

      <RBSheet
        ref={refRBSheet}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent",
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,

            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
            width: "100%",
            //     borderColor: "black",
            // borderStyle: "solid",
            // borderWidth: 2,
          },
        }}
      >
        <View style={{ flex: 1 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>Circuit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>Activité</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>Zone</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>Disponibilité</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* {circuitVisible && */}
          <ScrollView style={{ zIndex: 1 }}>
            <View style={styleH.contCircuit000}>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate("Circuit");
                  refRBSheet.current.close();
                }}
              >
                <Image
                  source={require("../../../assets/images/01.png")}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt10100}>
                    Circuit en famille
                  </Text>
                </TouchableOpacity>
              </TouchableOpacity>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate("Circuit");
                  refRBSheet.current.close();
                }}
              >
                <Image
                  source={require("../../../assets/images/02.png")}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt0100}>Circuit en amis</Text>
                </TouchableOpacity>
              </TouchableOpacity>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate("Circuit");
                  refRBSheet.current.close();
                }}
              >
                <Image
                  source={require("../../../assets/images/03.png")}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt0100}>
                    Circuit en couple
                  </Text>
                </TouchableOpacity>
              </TouchableOpacity>
              <TouchableOpacity
                style={styleH.circuit000}
                onPress={() => {
                  navigation.navigate("Circuit");
                  refRBSheet.current.close();
                }}
              >
                <Image
                  source={require("../../../assets/images/04.png")}
                  style={styleH.img00}
                />
                <TouchableOpacity style={styleH.circuitbtn0000}>
                  <Text style={styleH.circuitbtntxt0100}>Circuit en solo</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </RBSheet>

      <RBSheet
        ref={activite}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent",
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
          },
        }}
      >
        <View style={{ flex: 2 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>Circuit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>Activité</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>Zone</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>Disponibilité</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <ScrollView style={{ zIndex: 1 }}>
          <View style={styleH.containerFlex}>
            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/11.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/66.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/33.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/44.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/77.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/99.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/6.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>

            <View style={styleH.sousCont10}>
              <Image
                source={require("../../../assets/images/88.png")}
                style={styleH.img}
              />
              <Text style={styleH.souttitre}>Explorer la ville</Text>
              <Text style={styleH.souttitre2}>
                <Feather name="trending-up" size={10} color="#84ABE4" />
                Bonne opportunitée
              </Text>
              <View style={styleH.contabs20}>
                <View style={styleH.contabsNb20}>
                  <FontAwesome name="bookmark" size={13} color="#FFFFFF" />
                </View>
              </View>
              <View style={styleH.contprixmmm}>
                <View style={styleH.contNb}>
                  <Text style={styleH.conttxt}>400£</Text>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </RBSheet>

      <RBSheet
        ref={zone}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent",
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
          },
        }}
      >
        <View style={{ flex: 2 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>Circuit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>Activité</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>Zone</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>Disponibilité</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <ScrollView style={{ zIndex: 1 }}>
          <View>
            <MapView
              // ref={mapRef}
              style={{ width, height }}
              showsUserLocation
              followsUserLocation
            ></MapView>
          </View>
        </ScrollView>
      </RBSheet>

      <RBSheet
        ref={dispo}
        closeOnDragDown={false}
        closeOnPressMask={true}
        animationType="fade"
        customStyles={{
          wrapper: {
            backgroundColor: "transparent",
          },
          container: {
            backgroundColor: "#FFFFFF",
            height: "85%",
            borderTopLeftRadius: 10,
            borderTopRightRadius: 10,
          },
        }}
      >
        <View style={{ flex: 1 }}>
          <View style={styleH.menu}>
            <View style={styleH.menuMod}>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressCirc}>
                <Text style={styleH.menuModTxt}>Circuit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressAct}>
                <Text style={styleH.menuModTxt}>Activité</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous} onPress={PressZone}>
                <Text style={styleH.menuModTxt}>Zone</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styleH.menuModSous1} onPress={PressDisp}>
                <Text style={styleH.menuModTxt}>Disponibilité</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <ScrollView style={{ zIndex: 1 }}>
          <View style={styleH.contDispo}>
            <TouchableOpacity
              style={styleH.sousDispo}
              onPress={() => setModVisible(true)}
            >
              <Text style={styleH.sousDispoTxt}>Je suis disponible</Text>
              <AntDesign name="right" size={15} color="#84ABE4" />
            </TouchableOpacity>
            <TouchableOpacity style={styleH.sousDispo}>
              <Text style={styleH.sousDispoTxt}>
                Je suis disponible pendent
              </Text>
              <AntDesign name="right" size={15} color="#84ABE4" />
            </TouchableOpacity>
            <TouchableOpacity style={styleH.sousDispo}>
              <Text style={styleH.sousDispoTxt}>Je me déplace</Text>
              <AntDesign name="right" size={15} color="#84ABE4" />
            </TouchableOpacity>
            <TouchableOpacity style={styleH.sousDispo}>
              <Text style={styleH.sousDispoTxt}>
                Prendre en compte la météo
              </Text>
              <AntDesign name="right" size={15} color="#84ABE4" />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </RBSheet>

      {/* <Modal
        isVisible={activiteVisible}
        style={styleH.mod}
      >

      </Modal> */}

      {/* <Modal
        isVisible={zoneVisible}
        style={styleH.mod}
      >

      </Modal> */}
    </View>
  );
}
